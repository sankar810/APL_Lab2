package expressionparser;

import java.io.IOException;

import org.antlr.runtime.ANTLRFileStream;
import org.antlr.runtime.CommonTokenStream;
import org.antlr.runtime.RecognitionException;

public class Maiin {
	public static void main(String[] args) {

	try {
		ExprLexer lexer;
			lexer = new ExprLexer(new ANTLRFileStream(args[0]));
			CommonTokenStream tokens = new CommonTokenStream(lexer);
			ExprParser parser = new ExprParser(tokens);
			parser.prog();
				} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	catch (RecognitionException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
}
